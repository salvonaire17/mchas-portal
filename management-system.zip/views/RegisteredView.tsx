import React, { useState, useMemo } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { StudentDetails } from '../types';
import { motion } from 'motion/react';
import { 
    Search, 
    CheckCircle2, 
    Users, 
    FileSpreadsheet,
    GraduationCap,
    Clock,
    UserCheck,
    ArrowUpDown,
    ChevronLeft,
    ChevronRight,
    AlertTriangle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { collection, query, where, orderBy, limit, startAfter, getDocs } from 'firebase/firestore';

export const RegisteredView: React.FC = () => {
    const { courses = [], db } = useAuth() as any;
    const [searchQuery, setSearchQuery] = useState('');
    const [sortField, setSortField] = useState<'name' | 'indexNumber' | 'courseId'>('name');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
    
    // BACKEND PAGINATION STATE
    const [registeredStudents, setRegisteredStudents] = useState<any[]>([]);
    const [lastVisible, setLastVisible] = useState<any>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [hasMore, setHasMore] = useState(true);
    const studentsPerPage = 20;

    const fetchStudents = async (isInitial = true) => {
        if (isLoading || (!isInitial && !hasMore)) return;
        setIsLoading(true);

        try {
            const studentsRef = collection(db, 'users');
            // Query only registered students
            let q = query(
                studentsRef, 
                where('role', '==', 'Student'),
                where('registrationStatus', '==', 'Registered'),
                limit(studentsPerPage)
            );

            if (!isInitial && lastVisible) {
                q = query(
                    studentsRef, 
                    where('role', '==', 'Student'),
                    where('registrationStatus', '==', 'Registered'),
                    orderBy('name'),
                    startAfter(lastVisible),
                    limit(studentsPerPage)
                );
            }

            const snapshot = await getDocs(q);
            const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

            if (isInitial) {
                setRegisteredStudents(data);
            } else {
                setRegisteredStudents(prev => [...prev, ...data]);
            }

            if (snapshot.docs.length > 0) {
                setLastVisible(snapshot.docs[snapshot.docs.length - 1]);
            }
            setHasMore(snapshot.docs.length === studentsPerPage);
        } catch (err) {
            console.error("Error fetching registered students:", err);
        } finally {
            setIsLoading(false);
        }
    };

    React.useEffect(() => {
        fetchStudents(true);
    }, []);

    // Check for duplicates in the background (based on index numbers or emails)
    const duplicateMap = useMemo(() => {
        const counts: Record<string, number> = {};
        registeredStudents.forEach((s: any) => {
            const idx = (s.registrationWorkflow?.indexNumber || s.indexNumber || s.nactvetRegNo || s.email || '').toLowerCase().trim();
            if (idx) counts[idx] = (counts[idx] || 0) + 1;
        });
        return counts;
    }, [registeredStudents]);

    // Filtered already fetched list (incremental)
    const filteredStudents = useMemo(() => {
        let list = [...registeredStudents];
        if (searchQuery) {
            const term = searchQuery.toLowerCase();
            list = list.filter((student: any) => {
                const workflowIndex = student.registrationWorkflow?.indexNumber || '';
                const studentIdx = student.indexNumber || student.nactvetRegNo || '';
                return (
                    (student.name?.toLowerCase() || '').includes(term) ||
                    (student.email?.toLowerCase() || '').includes(term) ||
                    (student.courseId?.toLowerCase() || '').includes(term) ||
                    workflowIndex.toLowerCase().includes(term) ||
                    studentIdx.toLowerCase().includes(term)
                );
            });
        }

        // Apply sorting
        list.sort((a: any, b: any) => {
            let valA = '';
            let valB = '';

            if (sortField === 'name') {
                valA = a.name || '';
                valB = b.name || '';
            } else if (sortField === 'indexNumber') {
                valA = a.registrationWorkflow?.indexNumber || a.indexNumber || a.nactvetRegNo || '';
                valB = b.registrationWorkflow?.indexNumber || b.indexNumber || b.nactvetRegNo || '';
            } else if (sortField === 'courseId') {
                valA = a.courseId || '';
                valB = b.courseId || '';
            }

            if (sortDirection === 'asc') {
                return valA.localeCompare(valB);
            } else {
                return valB.localeCompare(valA);
            }
        });

        return list;
    }, [registeredStudents, searchQuery, sortField, sortDirection]);

    const handleSort = (field: 'name' | 'indexNumber' | 'courseId') => {
        if (sortField === field) {
            setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
        } else {
            setSortField(field);
            setSortDirection('asc');
        }
    };

    const handleExportToExcel = () => {
        if (filteredStudents.length === 0) return;

        const dataToExport = filteredStudents.map((student: any, idx) => ({
            "S/N": idx + 1,
            "Full Name": student.name,
            "Email Address": student.email,
            "Index Number (NACTVET)": student.registrationWorkflow?.indexNumber || student.indexNumber || student.nactvetRegNo || 'N/A',
            "Course / Program": student.courseId,
            "Financial Status": "Completed",
            "Hostel Status": "Completed",
            "NHIF Status": "Completed",
            "Cleared / Confirmed": "Yes"
        }));

        const worksheet = XLSX.utils.json_to_sheet(dataToExport);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Registered Students");
        XLSX.writeFile(workbook, `Registered_Students_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    };

    return (
        <div id="registered-view-root" className="space-y-8 animate-in fade-in duration-300">
            {/* Header section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-black text-slate-900 tracking-tight">Registered Directory</h1>
                    <p className="text-sm font-bold text-slate-500 mt-2">
                        Real-time master directory of all students who have successfully finalized admissions and confirmed clearance.
                    </p>
                </div>
                {filteredStudents.length > 0 && (
                    <button 
                        onClick={handleExportToExcel}
                        className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-widest rounded-2xl transition-all flex items-center gap-2 shadow-sm shadow-emerald-100 self-start md:self-auto active:scale-95 duration-200"
                    >
                        <FileSpreadsheet size={16} />
                        Export Directory to Excel
                    </button>
                )}
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-[2.5rem] border border-slate-150/70 shadow-sm flex items-center gap-5">
                    <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2.5xl flex items-center justify-center shadow-inner shrink-0 leading-none">
                        <UserCheck size={24} className="stroke-[2.5]" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] mb-1">Confirmed Registered</p>
                        <h4 className="text-3xl font-black text-slate-900 tracking-tight">{registeredStudents.length} Students</h4>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-[2.5rem] border border-slate-150/70 shadow-sm flex items-center gap-5">
                    <div className="w-14 h-14 bg-cyan-50 text-cyan-700 rounded-2.5xl flex items-center justify-center shadow-inner shrink-0 leading-none">
                        <GraduationCap size={24} className="stroke-[2.5]" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] mb-1">Cleared Programs</p>
                        <h4 className="text-3xl font-black text-slate-900 tracking-tight">
                            {Array.from(new Set(registeredStudents.map(s => s.courseId).filter(Boolean))).length} Active
                        </h4>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-[2.5rem] border border-slate-150/70 shadow-sm flex items-center gap-5">
                    <div className="w-14 h-14 bg-cyan-50 text-cyan-600 rounded-2.5xl flex items-center justify-center shadow-inner shrink-0 leading-none">
                        <Clock size={24} className="stroke-[2.5]" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] mb-1">Real-Time Sync</p>
                        <h4 className="text-xs font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1.5 mt-2">
                            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping inline-block" />
                            Connected to Database
                        </h4>
                    </div>
                </div>
            </div>

            {/* Search and List */}
            <div className="bg-white rounded-[2.5rem] border border-slate-155/70 shadow-sm overflow-hidden p-6 md:p-8 space-y-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="relative w-full sm:max-w-md">
                        <input 
                            type="text" 
                            placeholder="Search among loaded students by name, course, index..." 
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-11 pr-5 py-3.5 bg-slate-50 border border-slate-200/80 rounded-2xl font-semibold text-slate-800 focus:bg-white focus:ring-4 focus:ring-cyan-50 focus:border-cyan-400 outline-none transition-all placeholder:text-slate-400 text-sm"
                        />
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    </div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                        Loaded {filteredStudents.length} Students
                    </p>
                </div>

                {filteredStudents.length === 0 && !isLoading ? (
                    <div className="text-center py-20 bg-slate-50 rounded-[2.5rem] border border-dashed border-slate-200">
                        <div className="w-16 h-16 bg-slate-100 text-slate-300 rounded-full flex items-center justify-center mx-auto mb-6">
                            <Users size={32} />
                        </div>
                        <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight text-slate-800 tracking-tight">No Registered Students Found</h3>
                        <p className="text-sm text-slate-400 mt-2 max-w-sm mx-auto">
                            No student matching your filter criteria could be found in the current dataset. Try loading more records.
                        </p>
                    </div>
                ) : (
                    <>
                        {/* Mobile Card View */}
                        <div className="grid grid-cols-1 gap-4 md:hidden">
                            {filteredStudents.map((student: any, sIdx) => {
                                const indexNum = student.registrationWorkflow?.indexNumber || student.indexNumber || student.nactvetRegNo || 'N/A';
                                const isDuplicate = indexNum !== 'N/A' && duplicateMap[indexNum.toLowerCase().trim()] > 1;
                                return (
                                    <div key={student.id || sIdx} className={`bg-slate-50/50 p-6 rounded-[2.5rem] border transition-all ${isDuplicate ? 'border-amber-200 bg-amber-50/30' : 'border-slate-100'}`}>
                                        <div className="flex items-center gap-4">
                                            <div className="relative">
                                                <img 
                                                    referrerPolicy="no-referrer"
                                                    src={student.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(student.name || '')}`}
                                                    alt={student.name}
                                                    className="w-14 h-14 rounded-2xl bg-white object-cover border-2 border-white shadow-sm"
                                                />
                                                {isDuplicate && (
                                                    <div className="absolute -top-2 -right-2 bg-amber-500 text-white p-1 rounded-lg shadow-sm border border-white" title="Potential Duplicate Found">
                                                        <AlertTriangle size={12} />
                                                    </div>
                                                )}
                                            </div>
                                            <div className="min-w-0 flex-1">
                                                <p className="font-black text-slate-900 truncate leading-tight mb-1">{student.name}</p>
                                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest truncate">{student.email}</p>
                                                <div className="mt-2 flex items-center gap-2">
                                                    <span className="px-2.5 py-1 bg-white text-slate-600 font-black text-[9px] uppercase rounded-lg tracking-widest border border-slate-100">
                                                        {student.courseId || 'DEFAULT'}
                                                    </span>
                                                    {isDuplicate && (
                                                        <span className="text-[8px] font-black uppercase tracking-widest text-amber-600 bg-amber-100 px-2 py-1 rounded">Duplicate</span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-100">
                                            <div className="space-y-1">
                                                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Index Number</p>
                                                <p className="text-[10px] font-mono font-black text-slate-700">{indexNum}</p>
                                            </div>
                                            <div className="space-y-1">
                                                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Financial Status</p>
                                                <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 font-black uppercase tracking-wide">
                                                    <CheckCircle2 size={12} className="stroke-[2.5]" />
                                                    Cleared
                                                </div>
                                            </div>
                                            <div className="space-y-1">
                                                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Hostel Allocation</p>
                                                <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 font-black uppercase tracking-wide">
                                                    <CheckCircle2 size={12} className="stroke-[2.5]" />
                                                    Allocated
                                                </div>
                                            </div>
                                            <div className="space-y-1">
                                                <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">NHIF Status</p>
                                                <div className="flex items-center gap-1.5 text-[10px] text-emerald-600 font-black uppercase tracking-wide">
                                                    <CheckCircle2 size={12} className="stroke-[2.5]" />
                                                    Active
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>

                        {/* Desktop Table View */}
                        <div className="hidden md:block overflow-x-auto -mx-6 md:-mx-8">
                            <table className="w-full min-w-[900px]">
                            <thead>
                                <tr className="border-b border-slate-100 text-[10px] uppercase font-black tracking-widest text-slate-400">
                                    <th className="py-4 px-6 text-left">SN</th>
                                    <th className="py-4 px-6 text-left cursor-pointer select-none group" onClick={() => handleSort('name')}>
                                        <div className="flex items-center gap-1">
                                            Student Name 
                                            <ArrowUpDown size={12} className="text-slate-300 group-hover:text-slate-500 transition-colors" />
                                        </div>
                                    </th>
                                    <th className="py-4 px-6 text-left cursor-pointer select-none group" onClick={() => handleSort('indexNumber')}>
                                        <div className="flex items-center gap-1">
                                            NACTVET Index Number
                                            <ArrowUpDown size={12} className="text-slate-300 group-hover:text-slate-500 transition-colors" />
                                        </div>
                                    </th>
                                    <th className="py-4 px-6 text-left cursor-pointer select-none group" onClick={() => handleSort('courseId')}>
                                        <div className="flex items-center gap-1">
                                            Course ID
                                            <ArrowUpDown size={12} className="text-slate-300 group-hover:text-slate-500 transition-colors" />
                                        </div>
                                    </th>
                                    <th className="py-4 px-6 text-left">Financial Status</th>
                                    <th className="py-4 px-6 text-left">Hostel Status</th>
                                    <th className="py-4 px-6 text-left">NHIF Status</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50 text-sm">
                                {filteredStudents.map((student: any, sIdx) => {
                                    const indexNum = student.registrationWorkflow?.indexNumber || student.indexNumber || student.nactvetRegNo || 'N/A';
                                    const isDuplicate = indexNum !== 'N/A' && duplicateMap[indexNum.toLowerCase().trim()] > 1;
                                    return (
                                        <tr key={student.id || sIdx} className={`hover:bg-slate-50/70 transition-colors ${isDuplicate ? 'bg-amber-50/20' : ''}`}>
                                            <td className="py-4 px-6 font-mono font-black text-slate-400 text-xs">{sIdx + 1}</td>
                                            <td className="py-4 px-6">
                                                <div className="flex items-center gap-3">
                                                    <div className="relative">
                                                        <img 
                                                            referrerPolicy="no-referrer"
                                                            src={student.avatar || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(student.name || '')}`}
                                                            alt={student.name}
                                                            className="w-9 h-9 rounded-xl bg-slate-100 object-cover border border-slate-100 shrink-0"
                                                        />
                                                        {isDuplicate && (
                                                            <div className="absolute -top-1 -right-1 bg-amber-500 text-white p-0.5 rounded shadow-sm border border-white" title="Potential Duplicate Found">
                                                                <AlertTriangle size={8} />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div>
                                                        <div className="flex items-center gap-2">
                                                            <p className="font-black text-slate-800 leading-none">{student.name}</p>
                                                            {isDuplicate && (
                                                                <span className="text-[7px] font-black uppercase tracking-widest text-amber-600 bg-amber-100 px-1.5 py-0.5 rounded">DUP</span>
                                                            )}
                                                        </div>
                                                        <p className="text-[10px] text-slate-400 font-bold mt-1 uppercase tracking-wide">{student.email}</p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="py-4 px-6 font-mono font-black text-slate-700 text-xs tracking-tight">{indexNum}</td>
                                            <td className="py-4 px-6">
                                                <span className="px-2.5 py-1 bg-slate-100 text-slate-600 font-black text-[10px] uppercase rounded-lg tracking-widest border border-slate-150">
                                                    {student.courseId || 'DEFAULT'}
                                                </span>
                                            </td>
                                            <td className="py-4 px-6">
                                                <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-black uppercase tracking-wide">
                                                    <CheckCircle2 size={14} className="stroke-[2.5]" />
                                                    Completed
                                                </div>
                                            </td>
                                            <td className="py-4 px-6">
                                                <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-black uppercase tracking-wide">
                                                    <CheckCircle2 size={14} className="stroke-[2.5]" />
                                                    Completed
                                                </div>
                                            </td>
                                            <td className="py-4 px-6">
                                                <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-black uppercase tracking-wide">
                                                    <CheckCircle2 size={14} className="stroke-[2.5]" />
                                                    Completed
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>

                    {/* Load More Control */}
                    <div className="flex justify-center pt-8 border-t border-slate-100">
                        <button 
                            onClick={() => fetchStudents(false)} 
                            disabled={!hasMore || isLoading}
                            className={`px-10 py-4 rounded-[1.5rem] font-black text-xs uppercase tracking-[0.2em] transition-all shadow-sm ${hasMore ? 'bg-slate-900 text-white hover:bg-slate-800 active:scale-95 duration-200 shadow-slate-200' : 'bg-slate-100 text-slate-400 cursor-not-allowed shadow-none'}`}
                        >
                            {isLoading ? 'Loading Batch...' : hasMore ? 'Load Next 20 Students' : 'End of Directory'}
                        </button>
                    </div>
                   </>
                )}
            </div>
        </div>
    );
};
