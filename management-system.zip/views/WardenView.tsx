import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { StaffWorkflowLayout } from '../components/StaffWorkflowLayout';
import type { StudentDetails } from '../types';
import toast from 'react-hot-toast';

export const WardenView: React.FC = () => {
    const { user, students, courses, hostels, updateUser } = useAuth();

    if (!user || user.role !== 'Warden') {
        return (
            <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 p-12 text-center max-w-2xl mx-auto">
                <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 15v2m0 0v2m0-2h2m-2 0H8m13 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                </div>
                <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight text-slate-800 uppercase tracking-tight">Access Restricted</h3>
                <p className="text-slate-500 mt-4 font-medium leading-relaxed">Hostel management terminals are restricted to Warden staff only.</p>
            </div>
        );
    }
    
    const allocateRoom = (student: StudentDetails) => {
        let allocated = false;
        
        // Logical allocation from first available hostel/room
        for (const hostel of hostels) {
            for (const room of hostel.rooms) {
                const occupantsCount = students.filter(s => s.roomId === room.id).length;
                if (occupantsCount < room.capacity) {
                    updateUser(student.id, {
                        hostelStatus: 'Allocated',
                        hostelId: hostel.id,
                        roomId: room.id,
                        hostelAllocationDate: new Date().toISOString()
                    });
                    allocated = true;
                    toast.success(`Successfully allocated ${room.id} to ${student.name}`);
                    break;
                }
            }
            if (allocated) break;
        }

        if (!allocated) {
            toast.error('No available rooms in the institutional hostels.');
        }
    };

    const handleViewDetails = (student: StudentDetails) => {
        toast.success(`Showing hostel history for ${student.name}`);
    };

    return (
        <div className="space-y-6">
            {/* Dashboard Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Hostel Capacity</p>
                    <p className="text-4xl font-black text-slate-900">{hostels.reduce((acc, h) => acc + h.capacity, 0)}</p>
                </div>
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm text-center">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-2">Total Occupants</p>
                    <p className="text-4xl font-black text-emerald-600">{students.filter(s => s.hostelStatus === 'Allocated').length}</p>
                </div>
                <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm text-center">
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">Waiting List</p>
                    <p className="text-4xl font-black text-cyan-700">{students.filter(s => s.hostelStatus === 'Pending').length}</p>
                </div>
            </div>

            <StaffWorkflowLayout
                title="Hostel Allocation Terminal"
                officeRole="Warden's Office"
                students={students}
                courses={courses}
                waitingFilter={(s) => s.hostelStatus === 'Pending'}
                solvedFilter={(s) => s.hostelStatus === 'Allocated'}
                onProcessStudent={allocateRoom}
                onViewDetails={handleViewDetails}
            />
        </div>
    );
};
